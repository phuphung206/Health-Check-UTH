from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title='Converted FastAPI from Node.js')
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

# Include routers (auto-imported)
import importlib
import pkgutil
from pathlib import Path

routes_pkg = Path(__file__).parent / 'routes'
if routes_pkg.exists():
    for p in routes_pkg.glob('*.py'):
        if p.name.startswith('__'):
            continue
        mod = importlib.import_module(f"src.routes.{p.stem}")
        if hasattr(mod, 'router'):
            app.include_router(mod.router, prefix='/' + p.stem)

@app.get('/')
async def root():
    return {'message':'FastAPI app converted from Node.js (stubs).'}
