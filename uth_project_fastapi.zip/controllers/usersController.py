from fastapi import HTTPException
from typing import Any

# Controller stubs converted from JS

async def createUser(payload: Any = None):
    # TODO: port logic from JS
    return {'message':'stub createUser'}

async def getAllUsers(payload: Any = None):
    # TODO: port logic from JS
    return {'message':'stub getAllUsers'}

async def getUserById(payload: Any = None):
    # TODO: port logic from JS
    return {'message':'stub getUserById'}

async def updateUser(payload: Any = None):
    # TODO: port logic from JS
    return {'message':'stub updateUser'}

async def deleteUser(payload: Any = None):
    # TODO: port logic from JS
    return {'message':'stub deleteUser'}
