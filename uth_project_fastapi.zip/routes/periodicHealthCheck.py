from fastapi import APIRouter, HTTPException
from typing import Any
router = APIRouter()

# Controller functions will be imported from controllers (stubs)
from ..controllers import periodicHealthCheck as controller


@router.post('/')
async def create():
    # TODO: implement create
    return {'message':'stub create for /'}


@router.get('/')
async def getAll():
    # TODO: implement getAll
    return {'message':'stub getAll for /'}


@router.get('/:id')
async def getById():
    # TODO: implement getById
    return {'message':'stub getById for /:id'}


@router.put('/:id')
async def update():
    # TODO: implement update
    return {'message':'stub update for /:id'}


@router.delete('/:id')
async def remove():
    # TODO: implement remove
    return {'message':'stub remove for /:id'}

